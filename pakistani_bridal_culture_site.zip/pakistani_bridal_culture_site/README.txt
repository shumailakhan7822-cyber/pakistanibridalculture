GitHub Pages upload instructions:
1. Extract this ZIP file.
2. Upload index.html, style.css, and the images folder to your GitHub repository.
3. Go to Settings > Pages.
4. Select Source: Deploy from a branch, Branch: main, Folder: /(root), then Save.
5. Wait 2-10 minutes. Your site link will appear in Settings > Pages.
